let a =
  if_this_is_right() && then_this()

a = func_call()
  .map()
  .filter()
