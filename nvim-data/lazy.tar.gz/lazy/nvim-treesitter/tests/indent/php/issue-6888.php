<?php
enum DaysOfWeek: int
{
    case Sunday = 0;
    case Monday = 1;
}

class Foo {
    public int $id;
    public string $brand;
}
?>
