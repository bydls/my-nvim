/// Function foo
///
/// Description of
/// function foo.
fn foo(x: i32, y: i32) -> i32 {
    x + y
}

impl A {
    /// Do some stuff!! (put cursor here and press enter)
    fn a();
}

