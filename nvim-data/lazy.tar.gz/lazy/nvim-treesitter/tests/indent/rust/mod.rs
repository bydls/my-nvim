mod foo {
    const X: i32 = 1;

    mod bar {

        const Y: i32 = 1;
    }
}
