struct Foo {
    x: u32,
    y: u32,
}
