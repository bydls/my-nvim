(
    a, 
    b
)

foo.bar(
    a, b
)

foo = [
    1, 
    2, 
    3
]

foo = {
    "a": 1,
    "b": 2,
    "c": 3
}

foo = {
    1,
    2,
    3,
}

foo = (
    1 + 2
)

(
    a for a in range(0, 10)
)

foo = [
    a for a in range(0, 10)
]

foo = {
    a for a in range(0, 10)
}

foo = {
    a: b for a, b in items
}

foo.bar(
    "baz")

[
    a + b for (
        a, 
        b
    ) 
    in items
]

[
    a + b for [
        a,
        b
    ]
    in items
]
