begin
    create table foo (bar int);
end;
