insert into mytable
    (column1, column2)
values
    ('john', 123),
    ('jane', 124);
